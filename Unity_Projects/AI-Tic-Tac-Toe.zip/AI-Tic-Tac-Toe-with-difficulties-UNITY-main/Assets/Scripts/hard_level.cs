﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class hard_level : MonoBehaviour
{
    // Start is called before the first frame update
    public void hard()
    {
        Application.LoadLevel("hard");
    }
    }

