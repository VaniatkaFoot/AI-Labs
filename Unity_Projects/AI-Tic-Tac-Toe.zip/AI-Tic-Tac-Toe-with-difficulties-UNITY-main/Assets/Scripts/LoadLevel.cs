﻿using UnityEngine;
using System.Collections;

public class LoadLevel : MonoBehaviour {

	public void Load(){
        Application.LoadLevel("start");
    }
}
