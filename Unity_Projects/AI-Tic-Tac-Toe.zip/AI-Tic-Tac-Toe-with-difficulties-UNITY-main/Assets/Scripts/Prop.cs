﻿using UnityEngine;
using System.Collections;

public class Prop : MonoBehaviour {
    public int idx;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}

