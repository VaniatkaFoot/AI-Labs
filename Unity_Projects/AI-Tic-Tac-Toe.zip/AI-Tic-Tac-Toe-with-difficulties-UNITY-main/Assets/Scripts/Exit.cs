﻿using UnityEngine;
using System.Collections;

public class Exit : MonoBehaviour {

    void OnMouseDown()
    {
        Application.Quit();
    }
}
