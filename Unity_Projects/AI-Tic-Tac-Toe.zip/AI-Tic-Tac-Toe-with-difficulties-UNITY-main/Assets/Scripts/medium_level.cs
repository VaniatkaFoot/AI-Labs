﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class medium_level : MonoBehaviour
{
   public void medium()
    {
        Application.LoadLevel("medium");
    }
}
